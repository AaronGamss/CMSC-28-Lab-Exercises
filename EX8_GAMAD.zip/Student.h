#ifndef STUDENT_H
#define STUDENT_H

#include "PPerson.h"
#include <string>

class Student : public Person{
public:
    std::string Course;
    std::string Department;
    std::string College;

    void setCourse(const std::string& course){ 
		Course = course; 
	}
	
    void setDepartment(const std::string& dept){ 
		Department = dept; 
	}
	
    void setCollege(const std::string& col){ 
		College = col; 
	}

    std::string getCourse() const { return Course; }
    std::string getDepartment() const { return Department; }
    std::string getCollege() const { return College; }

private:
    std::string studentNum;

public:
    void setStudentNum(const std::string& stuNum){ 
		studentNum = stuNum; 
	}
	
    std::string getStudentNum() const { return studentNum; }
};

#endif

