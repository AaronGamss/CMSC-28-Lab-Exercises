#include <iostream>
#include "Employee.h"

int main() {
    std::cout << "This program will create an Employee object and display its details (user input).\n";
    std::cout << "Programmed by: Dan Aaron P. Gamad\n\n";

    Employees employee;

    std::string fname, lname, gender, empNum, position, officeUnit;
    double salary;

    std::cout << "Employee First Name: ";
    std::cin >> fname;
    std::cout << "Employee Last Name: ";
    std::cin >> lname;
    std::cout << "Employee Gender: ";
    std::cin >> gender;
    std::cout << "Employee Number: ";
    std::cin >> empNum;
    std::cout << "Position: ";
    std::cin.ignore();
    std::getline(std::cin, position);
    std::cout << "Office/Unit: ";
    std::getline(std::cin, officeUnit);
    std::cout << "Salary: ";
    std::cin >> salary;

    employee.setFname(fname);
    employee.setLname(lname);
    employee.setGender(gender);
    employee.setEmpNum(empNum);
    employee.setPosition(position);
    employee.setOfficeUnit(officeUnit);
    employee.setSalary(salary);

	std::cout << "\n==========RESULT==========";
    std::cout << "\nGood day, " << employee.getFname() << " " << employee.getLname() << "! Your employee number is " << employee.getEmpNum()
              << ". You are working as a " << employee.getPosition() << " in the " << employee.getOfficeUnit() << " office with a CRAZY salary of " << employee.getSalary() << ".\n";

    return 0;
}

