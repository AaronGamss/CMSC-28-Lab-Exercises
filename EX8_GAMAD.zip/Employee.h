#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include "PPerson.h"
#include <string>

class Employees : public Person{
public:
    std::string Position;
    std::string OfficeUnit;
    double Salary;

    void setPosition(const std::string& pos){ 
		Position = pos; 
	}
	
    void setOfficeUnit(const std::string& unit){ 
		OfficeUnit = unit; 
	}
	
    void setSalary(double sal){ 
		Salary = sal; 
	}

    std::string getPosition() const { return Position; }
    std::string getOfficeUnit() const { return OfficeUnit; }
    double getSalary() const { return Salary; }

private:
    std::string empNum;

public:
    void setEmpNum(const std::string& empNum){ 
		this->empNum = empNum; 
	}
    std::string getEmpNum() const { return empNum; }
};

#endif

