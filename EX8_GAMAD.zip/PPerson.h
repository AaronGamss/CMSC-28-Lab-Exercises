#ifndef PPERSON_H
#define PPERSON_H

#include <string>

class Person{
public:
    std::string fname;
    std::string lname;
    std::string gender;
    std::string emailAdd;
    std::string cpNumber;

    void setFname(const std::string& firstName){ 
		fname = firstName; 
	}
	
    void setLname(const std::string& lastName){ 
		lname = lastName; 
	}
	
    void setGender(const std::string& gen){ 
		gender = gen; 
	}
	
    void setEmailAdd(const std::string& email){ 
		emailAdd = email; 
	}
	
    void setCpNumber(const std::string& cpNum){ 
		cpNumber = cpNum; 
	}

    std::string getFname() const { return fname; }
    std::string getLname() const { return lname; }
    std::string getGender() const { return gender; }
    std::string getEmailAdd() const { return emailAdd; }
    std::string getCpNumber() const { return cpNumber; }
};

#endif

