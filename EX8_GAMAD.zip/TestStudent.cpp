#include <iostream>
#include "Student.h"

int main() {
    std::cout << "This program will create a Student object and display its details (user input).\n";
    std::cout << "Programmed by: Dan Aaron P. Gamad\n\n";

    Student student;

    std::string fname, lname, gender, studentNum, course, department, college;

    std::cout << "Student First Name: ";
    std::cin >> fname;
    std::cout << "Student Last Name: ";
    std::cin >> lname;
    std::cout << "Student Gender: ";
    std::cin >> gender;
    std::cout << "Student Number: ";
    std::cin >> studentNum;
    std::cout << "Course: ";
    std::cin.ignore();
    std::getline(std::cin, course);
    std::cout << "Department: ";
    std::getline(std::cin, department);
    std::cout << "College: ";
    std::getline(std::cin, college);

    student.setFname(fname);
    student.setLname(lname);
    student.setGender(gender);
    student.setStudentNum(studentNum);
    student.setCourse(course);
    student.setDepartment(department);
    student.setCollege(college);

	std::cout << "\n==========RESULT==========";
    std::cout << "\nHello there, " << student.getFname() << " " << student.getLname() << "! I would like to welcome you to UP Mindanao and congratulations for passing! "
              << "We are pleased to inform you that you are admitted in the " << student.getCourse() << " program under the Department of "
              << student.getDepartment() << ", College of " << student.getCollege() << ". Your official student number would be " << student.getStudentNum() << ". We wish you the best!\n";

    return 0;
}

