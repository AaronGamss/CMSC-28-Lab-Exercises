#include <string>

//DAN AARON P. GAMAD
//TASK 1

using namespace std;

class Book{
	
private:
    string title;
    string author;
    string isbn;
    string publisher;

public:
    //constructor
    Book(string title, string author, string isbn);

    //getter methods to be used
    string getTitle() const;
    string getAuthor() const;
    string getISBN() const;
    string getPublisher() const;

    //setter methods to be used
    void setTitle(string bktitle);
    void setAuthor(string bkauthor);
    void setISBN(string bkisbn);
    void setPublisher(string bkpublisher);
};

//constructor def
Book::Book(string title, string author, string isbn){
    this->title = title;
    this->author = author;
    this->isbn = isbn;
}

//getter method def
string Book::getTitle() const{
    return title;
}

string Book::getAuthor() const{
    return author;
}

string Book::getISBN() const{
    return isbn;
}

string Book::getPublisher() const{
    return publisher;
}

//setter method def
void Book::setTitle(string bktitle){
    title = bktitle;
}

void Book::setAuthor(string bkauthor){
    author = bkauthor;
}

void Book::setISBN(string bkisbn){
    isbn = bkisbn;
}

void Book::setPublisher(string bkpublisher){
    publisher = bkpublisher;
}

