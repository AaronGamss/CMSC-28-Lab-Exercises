#include <iostream>
#include "Book.h"

//DAN AARON P. GAMAD
//TASK 2

int main(){
	
    //test constructor and getter methods
    Book myBook("Naruto", "Kishimoto", "9781569319000");
    std::cout << "Title: " << myBook.getTitle() << std::endl;
    std::cout << "Author: " << myBook.getAuthor() << std::endl;
    std::cout << "ISBN: " << myBook.getISBN() << std::endl;

    //test setter methods
    myBook.setPublisher("Shueisha");
    std::cout << "\nPublisher: " << myBook.getPublisher() << std::endl;

    //test setter and getter methods for updating new info
    myBook.setTitle("Notruto");
    myBook.setAuthor("Aaron Gams");
    myBook.setISBN("97815693190202");
    
    //display to check updated info and if setter n getter methods work
    std::cout << "\nNew Updated Title: " << myBook.getTitle() << std::endl;
    std::cout << "New Updated Author: " << myBook.getAuthor() << std::endl;
    std::cout << "New Updated ISBN: " << myBook.getISBN() << std::endl;

    return 0;
}

