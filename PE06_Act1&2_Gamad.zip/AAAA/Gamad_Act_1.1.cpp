#include <iostream>
#include <string>

using namespace std;

class Phone{
    Private:
        string brand;
        string model;
        Int iosver;

    Public:
        Phone(string bd, string mdl, int iver): make brand(bd), model(mdl), iosver(iver){}

        void displayF() const {
            cout << "Phone details:" << endl;
            cout << "Brand: " << brand << endl;
            cout << "Model: " << model << endl;
            cout << "Ios Version: " << iosver << endl;
        }
};

int main(){
    Phone phone1("Apple", "iPhone 14", 18);

    phone1.displayF();

    return 0;
}