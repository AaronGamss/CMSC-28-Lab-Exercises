#include <iostream>
#include "TestApple.h"

int main(){
    Phone phone1("Apple", "iPhone 14", 18);

    phone1.displayF();

    return 0;
}
