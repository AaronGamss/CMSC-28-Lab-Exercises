#include <string>

using namespace std;

class Phone{
    private:
        string brand;
        string model;
        int iosver;

    public:
        Phone(string bd, string mdl, int iver): brand(bd), model(mdl), iosver(iver){}

        void displayF() const {
            cout << "Phone details:" << endl;
            cout << "Brand: " << brand << endl;
            cout << "Model: " << model << endl;
            cout << "Ios Version: " << iosver << endl;
        }
};
