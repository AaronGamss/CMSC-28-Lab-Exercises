#include <iostream>
#include "Person.h"
#include "Name.h"
using namespace std;

int main() {
    int age;
    char gender;
    string firstName, lastName;
    string border(50, '=');

    // Create the first Person object using the default constructor
    cout << "Creating the 1st Person object (p) using the default Constructor" << endl;
    Person p;

    // Input age
    cout << "\nInput age: ";
    cin >> age;
    p.setAge(age);

    // Input gender
    cout << "Input gender: ";
    cin >> gender;
    p.setGender(gender);

    // Input first name
    cout << "Input first name: ";
    cin >> firstName;

    // Input last name
    cout << "Input last name: ";
    cin >> lastName;
    p.setName(firstName, lastName);

    // Display the details of the person
    cout << border << endl;
    p.display();
    cout << border << endl;

    return 0;
}

