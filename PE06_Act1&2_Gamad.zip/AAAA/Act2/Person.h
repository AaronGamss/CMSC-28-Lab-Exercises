#ifndef PERSON_H
#define PERSON_H

#include <iostream>
#include <string>
#include "Name.h"
using namespace std;

class Person {
private:
    int age;
    char gender;
    Name name;

    // Identify generation based on birth year
    string identifyGeneration(int birthYear) const {
        if (birthYear >= 2011) return "Generation Alpha";
        if (birthYear >= 1997) return "Gen Z";
        if (birthYear >= 1981) return "Millennials";
        if (birthYear >= 1965) return "Generation X";
        if (birthYear >= 1946) return "Boomers";
        if (birthYear >= 1928) return "Silent Generation";
        if (birthYear >= 1901) return "Greatest Generation";
        return "Unknown Generation";
    }

public:
    // Default constructor
    Person() : age(0), gender('M'), name("John", "Doe") {}

    // Constructor with age
    Person(int newAge) : age(newAge), gender('M'), name("John", "Doe") {}

    // Constructor with age and gender
    Person(int newAge, char c) : age(newAge), gender(c), name("John", "Doe") {}

    // Setter for age
    void setAge(int newAge) {
        if (newAge >= 0) {
            age = newAge;
        } else {
            cout << "Invalid age!!!" << endl;
        }
    }

    // Getter for age
    int getAge() const { return age; }

    // Setter for gender
    void setGender(char c) {
        if (c == 'M' || c == 'F') {
            gender = c;
        } else {
            cout << "Invalid gender!!!" << endl;
        }
    }

    // Getter for gender
    char getGender() const { return gender; }

    // Display function
    void display() const {
        int birthYear = 2024 - age; // Calculate birth year
        cout << "Age: " << age << endl;
        cout << "Gender: " << gender << endl;
        cout << "First Name: " << name.getFirstName() << endl;
        cout << "Last Name: " << name.getLastName() << endl;
        cout << "Generation: " << identifyGeneration(birthYear) << endl;
    }

    // Setter for name
    void setName(string firstName, string lastName) {
        name.setFirstName(firstName);
        name.setLastName(lastName);
    }
};

#endif // PERSON_H
