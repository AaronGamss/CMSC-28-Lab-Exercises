#ifndef NAME_H
#define NAME_H

#include <string>
using namespace std;

class Name {
private:
    string firstName;
    string lastName;

public:
    // Constructor
    Name(string fname = "John", string lname = "Doe") : firstName(fname), lastName(lname) {}

    // Getter for first name
    string getFirstName() const { return firstName; }

    // Setter for first name
    void setFirstName(string fname) { firstName = fname; }

    // Getter for last name
    string getLastName() const { return lastName; }

    // Setter for last name
    void setLastName(string lname) { lastName = lname; }
};

#endif // NAME_H
