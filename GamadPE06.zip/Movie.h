#ifndef MOVIE_H
#define MOVIE_H

#include <string>
#include "Personn.h"

class Movie{
private:
    std::string title;
    std::string synopsis;
    std::string mpaaRating;
    std::string genre;
    Person director;
    Person actor;

public:
    //set
    void setTitle(const std::string& title);
    void setSynopsis(const std::string& synopsis);
    void setMpaaRating(const std::string& rating);
    void setGenre(const std::string& genre);
    void setDirector(const Person& director);
    void setActor(const Person& actor);

    //get
    std::string getTitle() const;
    std::string getSynopsis() const;
    std::string getMpaaRating() const;
    std::string getGenre() const;
    Person getDirector() const;
    Person getActor() const;
};

#endif 

