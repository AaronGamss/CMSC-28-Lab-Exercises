#ifndef PERSON_H
#define PERSON_H

#include <string>

class Person{
private:
    std::string fname;
    std::string lname;

public:
    //set
    void setFname(const std::string& fname);
    void setLname(const std::string& lname);

    //get 
    std::string getFname() const;
    std::string getLname() const;
};

#endif

