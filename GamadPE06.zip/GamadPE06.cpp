#include <iostream>
#include "Movie.h"
#include "Personn.h"

//movie class methods
//set
void Movie::setTitle(const std::string& t) { title = t; }
void Movie::setSynopsis(const std::string& s) { synopsis = s; }
void Movie::setMpaaRating(const std::string& r) { mpaaRating = r; }
void Movie::setGenre(const std::string& g) { genre = g; }
void Movie::setDirector(const Person& d) { director = d; }
void Movie::setActor(const Person& a) { actor = a; }

//get
std::string Movie::getTitle() const { return title; }
std::string Movie::getSynopsis() const { return synopsis; }
std::string Movie::getMpaaRating() const { return mpaaRating; }
std::string Movie::getGenre() const { return genre; }
Person Movie::getDirector() const { return director; }
Person Movie::getActor() const { return actor; }

//person class methods
//set
void Person::setFname(const std::string& f) { fname = f; }
void Person::setLname(const std::string& l) { lname = l; }

//get
std::string Person::getFname() const { return fname; }
std::string Person::getLname() const { return lname; }

int main(){
	
    Movie movie;
    Person director;
    Person actor;

    std::string input;
    
    std::cout << "This program will accept user input movie details and display them." << std::endl;
    std::cout << "Programmed by: Dan Aaron P. Gamad" << std::endl;
    std::cout << "=====================================================================" << std::endl;
    //accept movie details from user
    std::cout << "Enter Movie Title: ";
    std::getline(std::cin, input);
    movie.setTitle(input);

    std::cout << "Enter Synopsis: ";
    std::getline(std::cin, input);
    movie.setSynopsis(input);

    std::cout << "What is the MPAA Rating: ";
    std::getline(std::cin, input);
    movie.setMpaaRating(input);

    std::cout << "What is the Genre: ";
    std::getline(std::cin, input);
    movie.setGenre(input);

    //director details
    std::cout << "Who is the Director (Format:First Name Last Name): ";
    std::cin >> input;
    director.setFname(input);
    std::cin >> input;
    director.setLname(input);
    movie.setDirector(director);

    //main actor/actress details
    std::cout << "Who is the main Actor/Actress (Format:First Name Last Name): ";
    std::cin >> input;
    actor.setFname(input);
    std::cin >> input;
    actor.setLname(input);
    movie.setActor(actor);
	std::cout << "=====================================================================" << std::endl;
	
    //display movie details
    std::cout << ">MOVIE DETAILS<" << std::endl;
    std::cout << "Movie Title: " << movie.getTitle() << std::endl;
    std::cout << "Synopsis: " << movie.getSynopsis() << std::endl;
    std::cout << "MPAA Rating: " << movie.getMpaaRating() << std::endl;
    std::cout << "Genre: " << movie.getGenre() << std::endl;
    std::cout << "Director: " << movie.getDirector().getFname() << " " << movie.getDirector().getLname() << std::endl;
    std::cout << "Actor: " << movie.getActor().getFname() << " " << movie.getActor().getLname() << std::endl;
	std::cout << "=====================================================================" << std::endl;
	
    return 0;
}

