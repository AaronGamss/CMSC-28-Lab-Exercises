#include <iostream>
#include "ProductInventoryy.h"

//Dan Aaron P. Gamad
//main

int main(){
	
    //instances for clothing and electronics
    Clothing clothingItem;
    Electronics electronicItem;

    //input details clothing
    std::cout << "Enter details for Clothing Item:\n";
    clothingItem.inputDetails();
	
    //input details electronics
    std::cout << "\nEnter details for Electronics Item:\n";
    electronicItem.inputDetails();

    //print details
    std::cout << "==============================================================";
    std::cout << "\nClothing Item Details:\n";
    clothingItem.printDetails();
    std::cout << "==============================================================";
    std::cout << "\nElectronics Item Details:\n";
    electronicItem.printDetails();
    std::cout << "==============================================================\n";
    return 0;
}
