#ifndef PRODUCTINVENTORYY_H
#define PRODUCTINVENTORYY_H

#include <iostream>
#include <string>

//Dan Aaron P. Gamad
//header

//PRODUCT CLASS
class Product{
	
protected:
    std::string name;
    std::string brand;
    double price;
    int quantity;
    std::string description;
    std::string category;

public:
    //constructor used
    Product() : price(0.0), quantity(0) {}

    //setters and getters for each attribute (common)
    void setName(const std::string& name) { this->name = name; }
    std::string getName() const { return name; }

    void setBrand(const std::string& brand) { this->brand = brand; }
    std::string getBrand() const { return brand; }

    void setPrice(double price) { this->price = price; }
    double getPrice() const { return price; }

    void setQuantity(int quantity) { this->quantity = quantity; }
    int getQuantity() const { return quantity; }

    void setDescription(const std::string& description) { this->description = description; }
    std::string getDescription() const { return description; }

    void setCategory(const std::string& category) { this->category = category; }
    std::string getCategory() const { return category; }

    //methods used for input
    virtual void inputDetails(){
        std::cout << "Enter product name: ";
        std::getline(std::cin, name);
        std::cout << "Enter brand: ";
        std::getline(std::cin, brand);
        std::cout << "Enter price: ";
        std::cin >> price;
        std::cout << "Enter quantity: ";
        std::cin >> quantity;
        std::cin.ignore(); //ignore the newline character left
        std::cout << "Enter description: ";
        std::getline(std::cin, description);
        std::cout << "Enter category: ";
        std::getline(std::cin, category);
    }

    //methods used for print
    virtual void printDetails() const{
        std::cout << "Name: " << name << "\n"
                  << "Brand: " << brand << "\n"
                  << "Price: " << price << "\n"
                  << "Quantity: " << quantity << "\n"
                  << "Description: " << description << "\n"
                  << "Category: " << category << "\n";
    }

    virtual ~Product() = default;
};

//CLOTHING
class Clothing : public Product{
	
private:
    std::string size;
    std::string color;
    std::string material;

public:
    //constructor used
    Clothing() : Product() { category = "Clothing"; }

    //setters and getters for each attribute (unique)
    void setSize(const std::string& size) { this->size = size; }
    std::string getSize() const { return size; }

    void setColor(const std::string& color) { this->color = color; }
    std::string getColor() const { return color; }

    void setMaterial(const std::string& material) { this->material = material; }
    std::string getMaterial() const { return material; }

    //method used for input
    void inputDetails() override{
        Product::inputDetails();
        std::cout << "Enter size: ";
        std::getline(std::cin, size);
        std::cout << "Enter color: ";
        std::getline(std::cin, color);
        std::cout << "Enter material: ";
        std::getline(std::cin, material);
    }

    //method used for print
    void printDetails() const override{
        Product::printDetails();
        std::cout << "Size: " << size << "\n"
                  << "Color: " << color << "\n"
                  << "Material: " << material << "\n";
    }
};

//ELECTRONICS
class Electronics : public Product{

private:
    std::string model;
    float warranty; //warranty(years)
    std::string technicalSpecifications;

public:
    //constructor used
    Electronics() : Product(), warranty(0.0f) { category = "Electronics"; }

    //setters and getters for each attribute used (unique)
    void setModel(const std::string& model) { this->model = model; }
    std::string getModel() const { return model; }

    void setWarranty(float warranty) { this->warranty = warranty; }
    float getWarranty() const { return warranty; }

    void setTechnicalSpecifications(const std::string& technicalSpecifications) { this->technicalSpecifications = technicalSpecifications; }
    std::string getTechnicalSpecifications() const { return technicalSpecifications; }

    //method used for input
    void inputDetails() override{
        Product::inputDetails();
        std::cout << "Enter model: ";
        std::getline(std::cin, model);
        std::cout << "Enter warranty (years): ";
        std::cin >> warranty;
        std::cin.ignore(); //ignore the newline character left
        std::cout << "Enter technical specifications: ";
        std::getline(std::cin, technicalSpecifications);
    }

    //method used for print
    void printDetails() const override{
        Product::printDetails();
        std::cout << "Model: " << model << "\n"
                  << "Warranty: " << warranty << " years\n"
                  << "Technical Specifications: " << technicalSpecifications << "\n";
    }
};

#endif 
